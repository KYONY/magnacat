import{D as u,b as w,a as I,s as M}from"./shortcut-B8oKajzO.js";(function(){const n=document.createElement("link").relList;if(n&&n.supports&&n.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))l(t);new MutationObserver(t=>{for(const a of t)if(a.type==="childList")for(const r of a.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&l(r)}).observe(document,{childList:!0,subtree:!0});function i(t){const a={};return t.integrity&&(a.integrity=t.integrity),t.referrerPolicy&&(a.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?a.credentials="include":t.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function l(t){if(t.ep)return;t.ep=!0;const a=i(t);fetch(t.href,a)}})();function E(o){o==="dark"||o==="system"&&window.matchMedia("(prefers-color-scheme: dark)").matches?document.body.classList.add("dark"):document.body.classList.remove("dark")}function L(o){document.querySelectorAll(".theme-btn").forEach(n=>{n.classList.toggle("active",n.getAttribute("data-theme")===o)})}function p(o,n,i){if(o.innerHTML="",n.length===0){const l=document.createElement("option");l.value=i,l.textContent=i,o.appendChild(l);return}for(const l of n){const t=document.createElement("option");t.value=l.id,t.textContent=l.label,o.appendChild(t)}o.value=i}function k(){const o=document.getElementById("app");if(!o)return;o.innerHTML=`
    <div class="popup-container">
      <h2>Magnacat Translator</h2>

      <div class="field">
        <label for="api-key">Gemini API Key</label>
        <input type="password" id="api-key" data-testid="api-key-input" placeholder="Enter Gemini API key" />
      </div>

      <div class="field lang-row">
        <select data-testid="source-lang" id="source-lang">
          <option value="auto">Auto</option>
          <option value="en">English</option>
          <option value="uk">Ukrainian</option>
        </select>
        <button data-testid="swap-btn" id="swap-btn" title="Swap languages">⇄</button>
        <select data-testid="target-lang" id="target-lang">
          <option value="uk">Ukrainian</option>
          <option value="en">English</option>
          <option value="auto">Auto</option>
        </select>
      </div>

      <div class="field model-row">
        <label>Translation model</label>
        <select id="translate-model" data-testid="translate-model">
          <option value="">Loading...</option>
        </select>
      </div>

      <div class="field model-row">
        <label>TTS model</label>
        <select id="tts-model" data-testid="tts-model">
          <option value="">Loading...</option>
        </select>
      </div>

      <div class="theme-row" data-testid="theme-toggle">
        <button class="theme-btn" data-testid="theme-light" data-theme="light">Light</button>
        <button class="theme-btn" data-testid="theme-dark" data-theme="dark">Dark</button>
        <button class="theme-btn" data-testid="theme-system" data-theme="system">System</button>
      </div>

      <div class="toggle-row">
        <span>Show icon on selection</span>
        <label class="toggle-switch">
          <input type="checkbox" id="show-icon-toggle" data-testid="show-icon-toggle" />
          <span class="toggle-slider"></span>
        </label>
      </div>

      <div class="field shortcut-row">
        <label for="shortcut-input">Translation shortcut</label>
        <div class="shortcut-input-wrapper">
          <input type="text" id="shortcut-input" data-testid="shortcut-input" readonly placeholder="Click to record..." />
          <button id="shortcut-clear" data-testid="shortcut-clear" class="shortcut-clear-btn" title="Reset to default">&times;</button>
        </div>
      </div>

      <button data-testid="save-btn" id="save-btn">Save</button>
      <div data-testid="status-msg" id="status-msg"></div>
    </div>
  `;const n=document.getElementById("api-key"),i=document.getElementById("save-btn"),l=document.getElementById("swap-btn"),t=document.getElementById("source-lang"),a=document.getElementById("target-lang"),r=document.getElementById("status-msg"),f=document.getElementById("show-icon-toggle"),s=document.getElementById("shortcut-input"),T=document.getElementById("shortcut-clear"),h=document.getElementById("translate-model"),v=document.getElementById("tts-model");let c="system",m=u;s.value=u,chrome.runtime.sendMessage({type:"GET_API_KEY"},e=>{e?.success&&e.data&&(n.value=e.data)}),chrome.runtime.sendMessage({type:"GET_SETTINGS"},e=>{if(e?.success&&e.data){t.value=e.data.sourceLang,a.value=e.data.targetLang,c=e.data.theme??"system",f.checked=e.data.showTriggerIcon!==!1;const d=e.data.shortcut??u;s.value=d,m=d;const y=e.data.translateModel??w,b=e.data.ttsModel??I;E(c),L(c),chrome.runtime.sendMessage({type:"FETCH_MODELS"},g=>{g?.success&&g.data?(p(h,g.data.translateModels,y),p(v,g.data.ttsModels,b)):(p(h,[],y),p(v,[],b))})}}),document.querySelectorAll(".theme-btn").forEach(e=>{e.addEventListener("click",()=>{c=e.getAttribute("data-theme"),E(c),L(c)})}),s.addEventListener("focus",()=>{s.value="Press keys..."}),s.addEventListener("keydown",e=>{e.preventDefault();const d=M(e);d&&(s.value=d,m=d,s.blur())}),s.addEventListener("blur",()=>{s.value==="Press keys..."&&(s.value=m)}),T.addEventListener("click",()=>{s.value=u,m=u}),i.addEventListener("click",()=>{const e=n.value.trim();if(!e){r.textContent="Please enter a valid API key";return}chrome.runtime.sendMessage({type:"SAVE_API_KEY",apiKey:e},()=>{chrome.runtime.sendMessage({type:"SAVE_SETTINGS",settings:{sourceLang:t.value,targetLang:a.value,theme:c,showTriggerIcon:f.checked,shortcut:s.value,translateModel:h.value,ttsModel:v.value}},()=>{r.textContent="Settings saved"})})}),l.addEventListener("click",()=>{const e=t.value,d=a.value;t.value=d,a.value=e})}k();
