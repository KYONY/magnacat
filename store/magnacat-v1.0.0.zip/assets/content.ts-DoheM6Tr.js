import{p as U}from"./gemini-tts-ChwLDwcK.js";import{p as L,D as S,m as _}from"./shortcut-B8oKajzO.js";let m=null;function O(){const t=window.getSelection();return t?t.toString().trim():""}function A(){const t=document.activeElement;if(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement){const r=t.getBoundingClientRect();return{x:r.left+10,y:r.bottom+5}}const n=window.getSelection();if(!n||n.rangeCount===0)return null;const e=n.getRangeAt(0).getBoundingClientRect();return e.left===0&&e.top===0&&e.width===0?null:{x:e.left,y:e.bottom+5}}function N(){const t=document.activeElement;return!t||t===document.body?null:t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLElement&&(t.isContentEditable||t.contentEditable==="true")?t:null}function $(t){z(),m=()=>{const n=O();n&&t(n)},document.addEventListener("mouseup",m)}function z(){m&&(document.removeEventListener("mouseup",m),m=null)}function X(t){return t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement?t.value:t.textContent??""}function T(t,n){const o=e=>{const r=e;r.ctrlKey&&r.shiftKey&&r.key==="T"&&(r.preventDefault(),X(t).trim())};t.addEventListener("keydown",o)}function G(t,n){if(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement){const o=t.selectionStart??0,e=t.selectionEnd??t.value.length;if(o!==e){const r=t.value.substring(0,o),s=t.value.substring(e);t.value=r+n+s;const i=o+n.length;t.setSelectionRange(i,i)}else t.value=n;t.dispatchEvent(new Event("input",{bubbles:!0}))}else if(t.isContentEditable||t.getAttribute("contenteditable")==="true"){const o=window.getSelection();if(o&&o.rangeCount>0&&!o.isCollapsed){const e=o.getRangeAt(0);e.deleteContents(),e.insertNode(document.createTextNode(n)),o.collapseToEnd()}else t.textContent=n;t.dispatchEvent(new Event("input",{bubbles:!0}))}}const y="magnacat-tooltip",P="magnacat-trigger";let x=null,E=null,w=null,h=null,f=null;function K(){return`
    :host {
      all: initial;
      position: fixed;
      z-index: 2147483647;
      font-family: system-ui, -apple-system, sans-serif;
      font-size: 14px;
    }
    .tooltip {
      position: relative;
      background: #fff;
      color: #1a1a1a;
      border: 1px solid #e0e0e0;
      border-radius: 8px;
      padding: 10px 14px;
      padding-right: 32px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.12);
      max-width: 360px;
      word-wrap: break-word;
      cursor: grab;
      user-select: none;
    }
    .tooltip:active {
      cursor: grabbing;
    }
    .tooltip button {
      cursor: pointer;
    }
    .tooltip .translation-text {
      cursor: auto;
      user-select: text;
    }
    .close-btn {
      position: absolute;
      top: 6px;
      right: 6px;
      border: none;
      background: transparent;
      cursor: pointer;
      font-size: 14px;
      color: #999;
      width: 22px;
      height: 22px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 4px;
    }
    .close-btn:hover {
      background: #f0f0f0;
      color: #555;
    }
    .translation-text {
      margin-bottom: 8px;
      line-height: 1.4;
    }
    .actions {
      display: flex;
      gap: 6px;
    }
    .btn {
      border: none;
      background: #f0f0f0;
      border-radius: 4px;
      padding: 4px 8px;
      cursor: pointer;
      font-size: 13px;
    }
    .btn:hover {
      background: #e0e0e0;
    }
    .btn.loading {
      pointer-events: none;
      opacity: 0.7;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 28px;
    }
    .btn-spinner {
      width: 14px;
      height: 14px;
      border: 2px solid #ccc;
      border-top: 2px solid #555;
      border-radius: 50%;
      animation: spin 0.6s linear infinite;
      display: inline-block;
    }
    .loading {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .spinner {
      width: 16px;
      height: 16px;
      border: 2px solid #e0e0e0;
      border-top: 2px solid #555;
      border-radius: 50%;
      animation: spin 0.6s linear infinite;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    @media (prefers-color-scheme: dark) {
      :host(:not([data-theme="light"])) .tooltip {
        background: #2a2a2a;
        color: #e0e0e0;
        border-color: #444;
        box-shadow: 0 4px 16px rgba(0,0,0,0.4);
      }
      :host(:not([data-theme="light"])) .btn {
        background: #3a3a3a;
        color: #e0e0e0;
      }
      :host(:not([data-theme="light"])) .btn:hover {
        background: #4a4a4a;
      }
      :host(:not([data-theme="light"])) .close-btn {
        color: #777;
      }
      :host(:not([data-theme="light"])) .close-btn:hover {
        background: #3a3a3a;
        color: #ccc;
      }
      :host(:not([data-theme="light"])) .spinner {
        border-color: #555;
        border-top-color: #ccc;
      }
      :host(:not([data-theme="light"])) .btn-spinner {
        border-color: #555;
        border-top-color: #ccc;
      }
    }

    :host([data-theme="dark"]) .tooltip {
      background: #2a2a2a;
      color: #e0e0e0;
      border-color: #444;
      box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    }
    :host([data-theme="dark"]) .btn {
      background: #3a3a3a;
      color: #e0e0e0;
    }
    :host([data-theme="dark"]) .btn:hover {
      background: #4a4a4a;
    }
    :host([data-theme="dark"]) .close-btn {
      color: #777;
    }
    :host([data-theme="dark"]) .close-btn:hover {
      background: #3a3a3a;
      color: #ccc;
    }
    :host([data-theme="dark"]) .spinner {
      border-color: #555;
      border-top-color: #ccc;
    }
    :host([data-theme="dark"]) .btn-spinner {
      border-color: #555;
      border-top-color: #ccc;
    }
  `}function j(t){w=t}function Y(t,n,o){k();const e=document.createElement("div");e.id=y;const r=e.attachShadow({mode:"open"});try{chrome.storage.local.get("settings",c=>{const a=c?.settings?.theme;a&&a!=="system"&&e.setAttribute("data-theme",a)})}catch{}const s=document.createElement("style");s.textContent=K(),r.appendChild(s);const i=document.createElement("div");i.className="tooltip";const l=document.createElement("button");l.className="close-btn",l.setAttribute("data-testid","close-btn"),l.textContent="✕",l.title="Close",l.addEventListener("click",()=>k()),i.appendChild(l);const d=document.createElement("div");d.className="translation-text",d.setAttribute("data-testid","translation-text"),d.textContent=n,i.appendChild(d);const p=document.createElement("div");p.className="actions";const u=document.createElement("button");if(u.className="btn",u.setAttribute("data-testid","tts-btn"),u.textContent="🔊",u.title="Listen",o?.onTts){const c=o.onTts;u.addEventListener("click",()=>{if(u.classList.contains("loading"))return;u.classList.add("loading"),u.textContent="";const a=document.createElement("span");a.className="btn-spinner",u.appendChild(a),c(d.textContent??"").finally(()=>{u.classList.remove("loading"),u.textContent="🔊"})})}p.appendChild(u);const g=document.createElement("button");if(g.className="btn",g.setAttribute("data-testid","copy-btn"),g.textContent="📋",g.title="Copy",o?.onCopy){const c=o.onCopy;g.addEventListener("click",()=>c(d.textContent??""))}if(p.appendChild(g),o?.onReplace){const c=o.onReplace,a=document.createElement("button");a.className="btn",a.setAttribute("data-testid","replace-btn"),a.textContent="↻",a.title="Replace",a.addEventListener("click",()=>c(d.textContent??"")),p.appendChild(a)}if(o?.onSpellCheck){const c=o.onSpellCheck,a=document.createElement("button");a.className="btn",a.setAttribute("data-testid","spellcheck-btn"),a.textContent="✓",a.title="Check spelling",a.addEventListener("click",()=>{if(a.classList.contains("loading"))return;a.classList.add("loading"),a.textContent="";const H=document.createElement("span");H.className="btn-spinner",a.appendChild(H),c(d.textContent??"").then(q=>{d.textContent=q}).finally(()=>{a.classList.remove("loading"),a.textContent="✓"})}),p.appendChild(a)}i.appendChild(p),r.appendChild(i),e.style.left=`${t.x}px`,e.style.top=`${t.y}px`,document.body.appendChild(e),x=e;let C=!1,M=0,B=0;i.addEventListener("mousedown",c=>{c.target.closest("button, [data-testid='translation-text']")||(C=!0,M=c.clientX-e.getBoundingClientRect().left,B=c.clientY-e.getBoundingClientRect().top,c.preventDefault())}),h=c=>{C&&(e.style.left=`${c.clientX-M}px`,e.style.top=`${c.clientY-B}px`)},f=()=>{C=!1},document.addEventListener("mousemove",h),document.addEventListener("mouseup",f)}function k(){try{w?.()}catch{}if(w=null,h&&(document.removeEventListener("mousemove",h),h=null),f&&(document.removeEventListener("mouseup",f),f=null),x){x.remove(),x=null;return}document.getElementById(y)?.remove()}function D(t){const n=document.getElementById(y);if(!n?.shadowRoot)return;const o=n.shadowRoot.querySelector("[data-testid='translation-text']");o&&(o.textContent=t),n.shadowRoot.querySelector("[data-testid='loading']")?.remove()}function W(){const t=document.getElementById(y);if(!t?.shadowRoot)return;const n=t.shadowRoot.querySelector("[data-testid='translation-text']");if(n&&(n.textContent=""),t.shadowRoot.querySelector("[data-testid='loading']"))return;const e=t.shadowRoot.querySelector(".tooltip");if(!e)return;const r=document.createElement("div");r.className="loading",r.setAttribute("data-testid","loading");const s=document.createElement("div");s.className="spinner",r.appendChild(s);const i=document.createElement("span");i.textContent="Translating...",r.appendChild(i),e.insertBefore(r,e.firstChild)}function F(t,n){b();const o=document.createElement("div");o.id=P;const e=o.attachShadow({mode:"open"});try{chrome.storage.local.get("settings",l=>{const d=l?.settings?.theme;d&&d!=="system"&&o.setAttribute("data-theme",d)})}catch{}const r=document.createElement("style");r.textContent=`
    :host {
      all: initial;
      position: fixed;
      z-index: 2147483647;
    }
    .trigger {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      border: 1px solid #e0e0e0;
      background: #fff;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0;
    }
    .trigger:hover {
      box-shadow: 0 2px 12px rgba(0,0,0,0.25);
    }
    .trigger img {
      width: 20px;
      height: 20px;
    }

    @media (prefers-color-scheme: dark) {
      :host(:not([data-theme="light"])) .trigger {
        background: #2a2a2a;
        border-color: #444;
        box-shadow: 0 2px 8px rgba(0,0,0,0.4);
      }
      :host(:not([data-theme="light"])) .trigger:hover {
        box-shadow: 0 2px 12px rgba(0,0,0,0.5);
      }
    }

    :host([data-theme="dark"]) .trigger {
      background: #2a2a2a;
      border-color: #444;
      box-shadow: 0 2px 8px rgba(0,0,0,0.4);
    }
    :host([data-theme="dark"]) .trigger:hover {
      box-shadow: 0 2px 12px rgba(0,0,0,0.5);
    }
  `,e.appendChild(r);const s=document.createElement("button");s.className="trigger",s.setAttribute("data-testid","trigger-btn");const i=document.createElement("img");try{i.src=chrome.runtime.getURL("icons/icon-48.png")}catch{i.src="icons/icon-48.png"}i.alt="Translate",s.appendChild(i),s.addEventListener("click",l=>{l.stopPropagation(),n(),b()}),e.appendChild(s),o.style.left=`${t.x}px`,o.style.top=`${t.y}px`,document.body.appendChild(o),E=o}function b(){if(E){E.remove(),E=null;return}document.getElementById(P)?.remove()}let v=null,I=L(S);chrome.storage.local.get("settings").then(t=>{I=L(t?.settings?.shortcut??S)});chrome.storage.onChanged.addListener((t,n)=>{n==="local"&&t.settings?.newValue&&(I=L(t.settings.newValue.shortcut??S))});function J(t){const n=atob(t),o=new Uint8Array(n.length);for(let e=0;e<n.length;e++)o[e]=n.charCodeAt(e);return o.buffer}function R(t,n,o){const e={onTts:()=>new Promise(r=>{chrome.runtime.sendMessage({type:"TTS",text:t,voice:"Kore"},s=>{if(s?.success&&s.data){const i=J(s.data);v=U(i)}r()})}),onCopy:r=>{navigator.clipboard.writeText(r).catch(()=>{})}};o&&(e.onReplace=r=>{G(o,r),k()},e.onSpellCheck=()=>new Promise(r=>{chrome.runtime.sendMessage({type:"DETECT_LANG",text:t},s=>{const i=s?.data??"en";chrome.runtime.sendMessage({type:"SPELLCHECK",text:t,lang:i},l=>{l?.success?r(l.data):r(t)})})})),Y(n,"",e),j(()=>{v?.(),v=null}),W(),chrome.runtime.sendMessage({type:"DETECT_LANG",text:t},r=>{const i=r?.data==="uk"?"uk":"en",l=i==="uk"?"en":"uk";chrome.runtime.sendMessage({type:"TRANSLATE",text:t,from:i,to:l},d=>{d?.success?D(d.data):D("Translation error")})})}function Q(t){if(document.getElementById("magnacat-trigger"))return;const n=A();if(!n)return;const o=N();chrome.storage.local.get("settings").then(e=>{e?.settings?.showTriggerIcon!==!1&&F(n,()=>{R(t,n,o)})})}function V(t){return t.tagName==="INPUT"||t.tagName==="TEXTAREA"}function Z(){document.querySelectorAll("input, textarea, [contenteditable='true']").forEach(n=>T(n))}function tt(){new MutationObserver(n=>{for(const o of n)for(const e of o.addedNodes){if(!(e instanceof HTMLElement))continue;(V(e)||e.getAttribute("contenteditable")==="true")&&T(e),e.querySelectorAll("input, textarea, [contenteditable='true']").forEach(s=>T(s))}}).observe(document.body,{childList:!0,subtree:!0})}$(Q);Z();tt();document.addEventListener("mousedown",t=>{const n=document.getElementById("magnacat-trigger");n&&!n.contains(t.target)&&b()});chrome.runtime.onMessage.addListener(t=>{if(t.type==="CONTEXT_MENU_TRANSLATE"&&t.text){const n=A()??{x:window.innerWidth/2-100,y:window.innerHeight/2-50},o=N();b(),R(t.text,n,o)}});document.addEventListener("keydown",t=>{if(!_(t,I))return;const n=O();if(!n)return;t.preventDefault();const o=A()??{x:window.innerWidth/2-100,y:window.innerHeight/2-50},e=N();b(),R(n,o,e)});
