import{p as J}from"./gemini-tts-ChwLDwcK.js";import{p as B,D,m as xt}from"./shortcut-B8oKajzO.js";const Et=["www.youtube.com","m.youtube.com","youtube.com"],Ct="ytp-caption-window-container";function yt(){return Et.includes(location.hostname)}function Q(){return document.getElementById(Ct)}function vt(t){const e=document.getElementById("movie_player");if(!e)return null;const o=new MutationObserver(()=>{t(Q())});return o.observe(e,{childList:!0,subtree:!0}),()=>o.disconnect()}const V="data-mc-processed",Tt="mc-word";function St(t){if(t.getAttribute(V))return;const e=t.textContent??"";if(!e.trim())return;const o=e.split(/(\s+)/);t.textContent="";let n=0;for(const r of o)if(/^\s+$/.test(r))t.appendChild(document.createTextNode(r));else if(r){const i=document.createElement("span");i.className=Tt,i.textContent=r,i.setAttribute("data-index",String(n++)),i.setAttribute("data-sentence",e.trim()),t.appendChild(i)}t.setAttribute(V,"1")}function j(t){t.querySelectorAll(".ytp-caption-segment").forEach(St)}function wt(t){j(t);const e=new MutationObserver(()=>{j(t)});return e.observe(t,{childList:!0,subtree:!0,characterData:!0}),()=>{e.disconnect()}}const S="mc-selected",Z="mc-hover",y=".mc-word",l={selectedWords:[],lastClickedIndex:-1,parentSegment:null,onWordSelected:null,onSelectionCleared:null};function _(){for(const e of l.selectedWords)e.classList.remove(S);const t=l.selectedWords.length>0;l.selectedWords=[],l.lastClickedIndex=-1,l.parentSegment=null,t&&l.onSelectionCleared?.()}function tt(t){return parseInt(t.getAttribute("data-index")??"-1",10)}function Lt(t){return t.closest(".ytp-caption-segment")}function kt(t,e,o){const n=Math.min(e,o),r=Math.max(e,o),i=t.querySelectorAll(y);for(const s of l.selectedWords)s.classList.remove(S);l.selectedWords=[],i.forEach(s=>{const c=tt(s);c>=n&&c<=r&&(s.classList.add(S),l.selectedWords.push(s))})}function et(t){const e=t.target.closest(y);if(!e)return;t.stopPropagation(),t.preventDefault();const o=Lt(e);if(!o)return;const n=tt(e);t.shiftKey&&l.lastClickedIndex!==-1&&l.parentSegment===o?kt(o,l.lastClickedIndex,n):(_(),e.classList.add(S),l.selectedWords=[e],l.lastClickedIndex=n,l.parentSegment=o);const r=l.selectedWords.map(s=>s.textContent).join(" "),i=e.getAttribute("data-sentence")??r;l.onWordSelected?.({text:r,context:i})}function nt(t){const e=t.target.closest(y);e&&e.classList.add(Z)}function ot(t){const e=t.target.closest(y);e&&e.classList.remove(Z)}function rt(t){const e=t.target;!e.closest(y)&&!e.closest("#magnacat-tooltip")&&_()}let f=null;function At(t,e,o){l.onWordSelected=e,l.onSelectionCleared=o,f=t,t.addEventListener("mousedown",et,!0),t.addEventListener("mouseover",nt),t.addEventListener("mouseout",ot),document.addEventListener("mousedown",rt)}function it(){_(),f&&(f.removeEventListener("mousedown",et,!0),f.removeEventListener("mouseover",nt),f.removeEventListener("mouseout",ot)),document.removeEventListener("mousedown",rt),l.onWordSelected=null,l.onSelectionCleared=null,f=null}let P=!1;function st(){return document.querySelector("video")}function Nt(){const t=st();t&&(P=t.paused,t.paused||t.pause())}function It(){const t=st();t&&(P||t.play())}function at(){P=!1}const R="magnacat-subtitle-styles",Rt=`
.mc-word {
  cursor: pointer !important;
  user-select: none !important;
  border-radius: 2px;
  padding: 1px 2px;
  margin: 0 -2px;
  transition: background-color 0.15s ease;
  position: relative;
  display: inline;
}

.mc-word:hover,
.mc-word.mc-hover {
  background-color: rgba(255, 255, 100, 0.35) !important;
}

.mc-word.mc-selected {
  background-color: rgba(255, 255, 100, 0.65) !important;
}
`;function Mt(){if(document.getElementById(R))return;const t=document.createElement("style");t.id=R,t.textContent=Rt,document.head.appendChild(t)}function Ht(){document.getElementById(R)?.remove()}const k="magnacat-tooltip",ct="magnacat-trigger";let v=null,T=null,M=null,h=null,b=null;const Ot=new Set(["p","br","div","b","strong","i","em","u","s","sub","sup","h1","h2","h3","h4","h5","h6","ul","ol","li","blockquote","span"]);function lt(t){if(t.nodeType===Node.TEXT_NODE)return(t.textContent||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");if(t.nodeType!==Node.ELEMENT_NODE)return"";const e=t,o=e.tagName.toLowerCase();let n="";return e.childNodes.forEach(r=>{n+=lt(r)}),o==="br"?"<br>":Ot.has(o)?`<${o}>${n}</${o}>`:n}function Wt(t){const o=new DOMParser().parseFromString(t,"text/html");return lt(o.body)}function Bt(){return`
    :host {
      all: initial;
      position: fixed;
      z-index: 2147483647;
      font-family: system-ui, -apple-system, sans-serif;
      font-size: 14px;
    }
    .tooltip {
      position: relative;
      background: #fff;
      color: #1a1a1a;
      border: 1px solid #e0e0e0;
      border-radius: 8px;
      padding: 10px 14px;
      padding-right: 32px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.12);
      min-width: 200px;
      max-width: 600px;
      word-wrap: break-word;
      cursor: grab;
      user-select: none;
      resize: both;
      overflow: auto;
    }
    .tooltip:active {
      cursor: grabbing;
    }
    .tooltip button {
      cursor: pointer;
    }
    .tooltip .translation-text {
      cursor: auto;
      user-select: text;
    }
    .close-btn {
      position: absolute;
      top: 6px;
      right: 6px;
      border: none;
      background: transparent;
      cursor: pointer;
      font-size: 14px;
      color: #999;
      width: 22px;
      height: 22px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 4px;
    }
    .close-btn:hover {
      background: #f0f0f0;
      color: #555;
    }
    .translation-text {
      margin-bottom: 8px;
      line-height: 1.4;
      padding-left: 8px;
    }
    .translation-text p {
      margin: 0 0 1em 0;
    }
    .translation-text p:last-child {
      margin-bottom: 0;
    }
    .translation-text b, .translation-text strong {
      font-weight: bold;
    }
    .translation-text i, .translation-text em {
      font-style: italic;
    }
    .translation-text u {
      text-decoration: underline;
    }
    .actions {
      display: flex;
      gap: 6px;
    }
    .btn {
      border: none;
      background: #f0f0f0;
      border-radius: 4px;
      padding: 4px 8px;
      cursor: pointer;
      font-size: 13px;
    }
    .btn:hover {
      background: #e0e0e0;
    }
    .btn.loading {
      pointer-events: none;
      opacity: 0.7;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 28px;
    }
    .btn-spinner {
      width: 14px;
      height: 14px;
      border: 2px solid #ccc;
      border-top: 2px solid #555;
      border-radius: 50%;
      animation: spin 0.6s linear infinite;
      display: inline-block;
    }
    .loading {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .spinner {
      width: 16px;
      height: 16px;
      border: 2px solid #e0e0e0;
      border-top: 2px solid #555;
      border-radius: 50%;
      animation: spin 0.6s linear infinite;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    @media (prefers-color-scheme: dark) {
      :host(:not([data-theme="light"])) .tooltip {
        background: #2a2a2a;
        color: #e0e0e0;
        border-color: #444;
        box-shadow: 0 4px 16px rgba(0,0,0,0.4);
      }
      :host(:not([data-theme="light"])) .btn {
        background: #3a3a3a;
        color: #e0e0e0;
      }
      :host(:not([data-theme="light"])) .btn:hover {
        background: #4a4a4a;
      }
      :host(:not([data-theme="light"])) .close-btn {
        color: #777;
      }
      :host(:not([data-theme="light"])) .close-btn:hover {
        background: #3a3a3a;
        color: #ccc;
      }
      :host(:not([data-theme="light"])) .spinner {
        border-color: #555;
        border-top-color: #ccc;
      }
      :host(:not([data-theme="light"])) .btn-spinner {
        border-color: #555;
        border-top-color: #ccc;
      }
    }

    :host([data-theme="dark"]) .tooltip {
      background: #2a2a2a;
      color: #e0e0e0;
      border-color: #444;
      box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    }
    :host([data-theme="dark"]) .btn {
      background: #3a3a3a;
      color: #e0e0e0;
    }
    :host([data-theme="dark"]) .btn:hover {
      background: #4a4a4a;
    }
    :host([data-theme="dark"]) .close-btn {
      color: #777;
    }
    :host([data-theme="dark"]) .close-btn:hover {
      background: #3a3a3a;
      color: #ccc;
    }
    :host([data-theme="dark"]) .spinner {
      border-color: #555;
      border-top-color: #ccc;
    }
    :host([data-theme="dark"]) .btn-spinner {
      border-color: #555;
      border-top-color: #ccc;
    }
  `}function dt(t){M=t}function ut(t,e,o){E();const n=document.createElement("div");n.id=k;const r=n.attachShadow({mode:"open"});try{chrome.storage.local.get("settings",d=>{const a=d?.settings?.theme;a&&a!=="system"&&n.setAttribute("data-theme",a)})}catch{}const i=document.createElement("style");i.textContent=Bt(),r.appendChild(i);const s=document.createElement("div");s.className="tooltip";const c=document.createElement("button");c.className="close-btn",c.setAttribute("data-testid","close-btn"),c.textContent="✕",c.title="Close",c.addEventListener("click",()=>E()),s.appendChild(c);const u=document.createElement("div");u.className="translation-text",u.setAttribute("data-testid","translation-text"),u.textContent=e,s.appendChild(u);const m=document.createElement("div");m.className="actions";const p=document.createElement("button");if(p.className="btn",p.setAttribute("data-testid","tts-btn"),p.textContent="🔊",p.title="Listen",o?.onTts){const d=o.onTts;p.addEventListener("click",()=>{if(p.classList.contains("loading"))return;p.classList.add("loading"),p.textContent="";const a=document.createElement("span");a.className="btn-spinner",p.appendChild(a),d(u.textContent??"").finally(()=>{p.classList.remove("loading"),p.textContent="🔊"})})}m.appendChild(p);const g=document.createElement("button");if(g.className="btn",g.setAttribute("data-testid","copy-btn"),g.textContent="📋",g.title="Copy",o?.onCopy){const d=o.onCopy;g.addEventListener("click",()=>d(u.textContent??""))}if(m.appendChild(g),o?.onReplace){const d=o.onReplace,a=document.createElement("button");a.className="btn",a.setAttribute("data-testid","replace-btn"),a.textContent="↻",a.title="Replace",a.addEventListener("click",()=>d(u.textContent??"")),m.appendChild(a)}if(o?.onSpellCheck){const d=o.onSpellCheck,a=document.createElement("button");a.className="btn",a.setAttribute("data-testid","spellcheck-btn"),a.textContent="✓",a.title="Check spelling",a.addEventListener("click",()=>{if(a.classList.contains("loading"))return;a.classList.add("loading"),a.textContent="";const K=document.createElement("span");K.className="btn-spinner",a.appendChild(K),d(u.textContent??"").then(bt=>{u.textContent=bt}).finally(()=>{a.classList.remove("loading"),a.textContent="✓"})}),m.appendChild(a)}s.appendChild(m),r.appendChild(s),n.style.left=`${t.x}px`,n.style.top=`${t.y}px`,document.body.appendChild(n),v=n;let A=!1,G=0,X=0;s.addEventListener("mousedown",d=>{if(d.target.closest("button, [data-testid='translation-text']"))return;const a=s.getBoundingClientRect();a.width>0&&a.height>0&&d.clientX>a.right-18&&d.clientY>a.bottom-18||(A=!0,G=d.clientX-n.getBoundingClientRect().left,X=d.clientY-n.getBoundingClientRect().top,d.preventDefault())}),h=d=>{A&&(n.style.left=`${d.clientX-G}px`,n.style.top=`${d.clientY-X}px`)},b=()=>{A=!1},document.addEventListener("mousemove",h),document.addEventListener("mouseup",b)}function E(){try{M?.()}catch{}if(M=null,h&&(document.removeEventListener("mousemove",h),h=null),b&&(document.removeEventListener("mouseup",b),b=null),v){v.remove(),v=null;return}document.getElementById(k)?.remove()}function w(t){const e=document.getElementById(k);if(!e?.shadowRoot)return;const o=e.shadowRoot.querySelector("[data-testid='translation-text']");o&&(/<[a-z][\s\S]*?>/i.test(t)?o.innerHTML=Wt(t):o.textContent=t),e.shadowRoot.querySelector("[data-testid='loading']")?.remove()}function pt(){const t=document.getElementById(k);if(!t?.shadowRoot)return;const e=t.shadowRoot.querySelector("[data-testid='translation-text']");if(e&&(e.textContent=""),t.shadowRoot.querySelector("[data-testid='loading']"))return;const n=t.shadowRoot.querySelector(".tooltip");if(!n)return;const r=document.createElement("div");r.className="loading",r.setAttribute("data-testid","loading");const i=document.createElement("div");i.className="spinner",r.appendChild(i);const s=document.createElement("span");s.textContent="Translating...",r.appendChild(s),n.insertBefore(r,n.firstChild)}function Dt(t,e){C();const o=document.createElement("div");o.id=ct;const n=o.attachShadow({mode:"open"});try{chrome.storage.local.get("settings",c=>{const u=c?.settings?.theme;u&&u!=="system"&&o.setAttribute("data-theme",u)})}catch{}const r=document.createElement("style");r.textContent=`
    :host {
      all: initial;
      position: fixed;
      z-index: 2147483647;
    }
    .trigger {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      border: 1px solid #e0e0e0;
      background: #fff;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 0;
    }
    .trigger:hover {
      box-shadow: 0 2px 12px rgba(0,0,0,0.25);
    }
    .trigger img {
      width: 20px;
      height: 20px;
    }

    @media (prefers-color-scheme: dark) {
      :host(:not([data-theme="light"])) .trigger {
        background: #2a2a2a;
        border-color: #444;
        box-shadow: 0 2px 8px rgba(0,0,0,0.4);
      }
      :host(:not([data-theme="light"])) .trigger:hover {
        box-shadow: 0 2px 12px rgba(0,0,0,0.5);
      }
    }

    :host([data-theme="dark"]) .trigger {
      background: #2a2a2a;
      border-color: #444;
      box-shadow: 0 2px 8px rgba(0,0,0,0.4);
    }
    :host([data-theme="dark"]) .trigger:hover {
      box-shadow: 0 2px 12px rgba(0,0,0,0.5);
    }
  `,n.appendChild(r);const i=document.createElement("button");i.className="trigger",i.setAttribute("data-testid","trigger-btn");const s=document.createElement("img");try{s.src=chrome.runtime.getURL("icons/icon-48.png")}catch{s.src="icons/icon-48.png"}s.alt="Translate",i.appendChild(s),i.addEventListener("click",c=>{c.stopPropagation(),e(),C()}),n.appendChild(i),o.style.left=`${t.x}px`,o.style.top=`${t.y}px`,document.body.appendChild(o),T=o}function C(){if(T){T.remove(),T=null;return}document.getElementById(ct)?.remove()}let L=null,H=null,N=null,O=!1;function _t(t){const e=atob(t),o=new Uint8Array(e.length);for(let n=0;n<e.length;n++)o[n]=e.charCodeAt(n);return o.buffer}function Pt(t){Nt();const e={x:window.innerWidth/2-150,y:window.innerHeight-200};ut(e,"",{onTts:n=>new Promise(r=>{chrome.runtime.sendMessage({type:"TTS",text:n,voice:"Kore"},i=>{if(i?.success&&i.data){const s=_t(i.data);N=J(s)}r()})}),onCopy:n=>{navigator.clipboard.writeText(n).catch(()=>{})}}),dt(()=>{N?.(),N=null,It(),at()}),pt(),chrome.runtime.sendMessage({type:"DETECT_LANG",text:t.text},n=>{const i=n?.data==="uk"?"uk":"en",s=i==="uk"?"en":"uk";chrome.runtime.sendMessage({type:"TRANSLATE",text:t.text,from:i,to:s,context:t.context},c=>{c?.success?w(c.data):w("Translation error")})})}function $t(){E()}function F(t){L?.(),it(),Mt(),L=wt(t),At(t,Pt,$t)}function mt(){L?.(),L=null,it(),E(),at()}function gt(){if(!yt()||O)return;O=!0;const t=Q();t&&F(t),H=vt(e=>{e?F(e):mt()})}function qt(){mt(),Ht(),H?.(),H=null,O=!1}let x=null;function ft(){const t=window.getSelection();return t?t.toString().trim():""}const Ut=new Set(["p","div","h1","h2","h3","h4","h5","h6","blockquote","ul","ol","li"]),zt=new Set(["b","strong","i","em","u","s","sub","sup"]);function ht(t){if(t.nodeType===Node.TEXT_NODE)return t.textContent||"";if(t.nodeType!==Node.ELEMENT_NODE)return"";const e=t,o=e.tagName.toLowerCase();let n="";if(e.childNodes.forEach(c=>{n+=ht(c)}),o==="br")return"<br>";if(Ut.has(o)||zt.has(o))return`<${o}>${n}</${o}>`;const r=e.style;let i="",s="";return(r.fontWeight==="bold"||r.fontWeight==="700"||Number(r.fontWeight)>=700)&&(i+="<b>",s="</b>"+s),r.fontStyle==="italic"&&(i+="<i>",s="</i>"+s),(r.textDecoration?.includes("underline")||r.textDecorationLine?.includes("underline"))&&(i+="<u>",s="</u>"+s),i+n+s}function $(){try{const t=window.getSelection();if(!t||t.rangeCount===0)return"";const e=document.createElement("div");for(let n=0;n<t.rangeCount;n++)e.appendChild(t.getRangeAt(n).cloneContents());let o="";return e.childNodes.forEach(n=>{o+=ht(n)}),o.trim()}catch{return""}}function q(){const t=document.activeElement;if(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement){const r=t.getBoundingClientRect();return{x:r.left+10,y:r.bottom+5}}const e=window.getSelection();if(!e||e.rangeCount===0)return null;const n=e.getRangeAt(0).getBoundingClientRect();return n.left===0&&n.top===0&&n.width===0?null:{x:n.left,y:n.bottom+5}}function U(){const t=document.activeElement;return!t||t===document.body?null:t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLElement&&(t.isContentEditable||t.contentEditable==="true")?t:null}function Yt(t){Gt(),x=()=>{const e=ft();e&&t(e)},document.addEventListener("mouseup",x)}function Gt(){x&&(document.removeEventListener("mouseup",x),x=null)}function Xt(t){return t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement?t.value:t.textContent??""}function W(t,e){const o=n=>{const r=n;r.ctrlKey&&r.shiftKey&&r.key==="T"&&(r.preventDefault(),Xt(t).trim())};t.addEventListener("keydown",o)}function Kt(t,e){if(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement){const o=t.selectionStart??0,n=t.selectionEnd??t.value.length;if(o!==n){const r=t.value.substring(0,o),i=t.value.substring(n);t.value=r+e+i;const s=o+e.length;t.setSelectionRange(s,s)}else t.value=e;t.dispatchEvent(new Event("input",{bubbles:!0}))}else if(t.isContentEditable||t.getAttribute("contenteditable")==="true"){const o=window.getSelection();if(o&&o.rangeCount>0&&!o.isCollapsed){const n=o.getRangeAt(0);n.deleteContents(),n.insertNode(document.createTextNode(e)),o.collapseToEnd()}else t.textContent=e;t.dispatchEvent(new Event("input",{bubbles:!0}))}}let I=null,z=B(D);chrome.storage.local.get("settings").then(t=>{z=B(t?.settings?.shortcut??D)});chrome.storage.onChanged.addListener((t,e)=>{e==="local"&&t.settings?.newValue&&(z=B(t.settings.newValue.shortcut??D),t.settings.newValue.youtubeSubtitles?gt():qt())});function Vt(t){const e=atob(t),o=new Uint8Array(e.length);for(let n=0;n<e.length;n++)o[n]=e.charCodeAt(n);return o.buffer}function Y(t,e,o,n){const r={onTts:()=>new Promise(i=>{chrome.runtime.sendMessage({type:"TTS",text:t,voice:"Kore"},s=>{if(s?.success&&s.data){const c=Vt(s.data);I=J(c)}i()})}),onCopy:i=>{navigator.clipboard.writeText(i).catch(()=>{})}};o&&(r.onReplace=i=>{Kt(o,i),E()},r.onSpellCheck=()=>new Promise(i=>{chrome.runtime.sendMessage({type:"DETECT_LANG",text:t},s=>{const c=s?.data??"en";chrome.runtime.sendMessage({type:"SPELLCHECK",text:t,lang:c},u=>{u?.success?i(u.data):i(t)})})})),ut(e,"",r),dt(()=>{I?.(),I=null}),pt(),chrome.runtime.sendMessage({type:"DETECT_LANG",text:t},i=>{const c=i?.data==="uk"?"uk":"en",u=c==="uk"?"en":"uk",m=n||t;chrome.runtime.sendMessage({type:"TRANSLATE",text:m,from:c,to:u},p=>{p?.success?w(p.data):w("Translation error")})})}function jt(t){if(document.getElementById("magnacat-trigger"))return;const e=q();if(!e)return;const o=U(),n=$();chrome.storage.local.get("settings").then(r=>{r?.settings?.showTriggerIcon!==!1&&Dt(e,()=>{Y(t,e,o,n)})})}function Ft(t){return t.tagName==="INPUT"||t.tagName==="TEXTAREA"}function Jt(){document.querySelectorAll("input, textarea, [contenteditable='true']").forEach(e=>W(e))}function Qt(){new MutationObserver(e=>{for(const o of e)for(const n of o.addedNodes){if(!(n instanceof HTMLElement))continue;(Ft(n)||n.getAttribute("contenteditable")==="true")&&W(n),n.querySelectorAll("input, textarea, [contenteditable='true']").forEach(i=>W(i))}}).observe(document.body,{childList:!0,subtree:!0})}Yt(jt);Jt();Qt();chrome.storage.local.get("settings").then(t=>{t?.settings?.youtubeSubtitles&&gt()});document.addEventListener("mousedown",t=>{const e=document.getElementById("magnacat-trigger");e&&!e.contains(t.target)&&C()});chrome.runtime.onMessage.addListener(t=>{if(t.type==="CONTEXT_MENU_TRANSLATE"&&t.text){const e=q()??{x:window.innerWidth/2-100,y:window.innerHeight/2-50},o=U(),n=$();C(),Y(t.text,e,o,n)}});document.addEventListener("keydown",t=>{if(!xt(t,z))return;const e=ft();if(!e)return;t.preventDefault();const o=q()??{x:window.innerWidth/2-100,y:window.innerHeight/2-50},n=U(),r=$();C(),Y(e,o,n,r)});
