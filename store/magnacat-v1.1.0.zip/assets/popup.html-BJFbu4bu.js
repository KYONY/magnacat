import{D as r,b as w,a as I,s as S}from"./shortcut-B8oKajzO.js";(function(){const s=document.createElement("link").relList;if(s&&s.supports&&s.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))l(e);new MutationObserver(e=>{for(const a of e)if(a.type==="childList")for(const u of a.addedNodes)u.tagName==="LINK"&&u.rel==="modulepreload"&&l(u)}).observe(document,{childList:!0,subtree:!0});function i(e){const a={};return e.integrity&&(a.integrity=e.integrity),e.referrerPolicy&&(a.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?a.credentials="include":e.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function l(e){if(e.ep)return;e.ep=!0;const a=i(e);fetch(e.href,a)}})();function L(o){o==="dark"||o==="system"&&window.matchMedia("(prefers-color-scheme: dark)").matches?document.body.classList.add("dark"):document.body.classList.remove("dark")}function T(o){document.querySelectorAll(".theme-btn").forEach(s=>{s.classList.toggle("active",s.getAttribute("data-theme")===o)})}function p(o,s,i){if(o.innerHTML="",s.length===0){const l=document.createElement("option");l.value=i,l.textContent=i,o.appendChild(l);return}for(const l of s){const e=document.createElement("option");e.value=l.id,e.textContent=l.label,o.appendChild(e)}o.value=i}function M(){const o=document.getElementById("app");if(!o)return;o.innerHTML=`
    <div class="popup-container">
      <h2>Magnacat Translator</h2>

      <div class="field">
        <label for="api-key">Gemini API Key</label>
        <input type="password" id="api-key" data-testid="api-key-input" placeholder="Enter Gemini API key" />
      </div>

      <div class="field lang-row">
        <select data-testid="source-lang" id="source-lang">
          <option value="auto">Auto</option>
          <option value="en">English</option>
          <option value="uk">Ukrainian</option>
        </select>
        <button data-testid="swap-btn" id="swap-btn" title="Swap languages">⇄</button>
        <select data-testid="target-lang" id="target-lang">
          <option value="uk">Ukrainian</option>
          <option value="en">English</option>
          <option value="auto">Auto</option>
        </select>
      </div>

      <div class="field model-row">
        <label>Translation model</label>
        <select id="translate-model" data-testid="translate-model">
          <option value="">Loading...</option>
        </select>
      </div>

      <div class="field model-row">
        <label>TTS model</label>
        <select id="tts-model" data-testid="tts-model">
          <option value="">Loading...</option>
        </select>
      </div>

      <div class="theme-row" data-testid="theme-toggle">
        <button class="theme-btn" data-testid="theme-light" data-theme="light">Light</button>
        <button class="theme-btn" data-testid="theme-dark" data-theme="dark">Dark</button>
        <button class="theme-btn" data-testid="theme-system" data-theme="system">System</button>
      </div>

      <div class="toggle-row">
        <span>Show icon on selection</span>
        <label class="toggle-switch">
          <input type="checkbox" id="show-icon-toggle" data-testid="show-icon-toggle" />
          <span class="toggle-slider"></span>
        </label>
      </div>

      <div class="toggle-row">
        <span>YouTube subtitles</span>
        <label class="toggle-switch">
          <input type="checkbox" id="youtube-subtitles-toggle" data-testid="youtube-subtitles-toggle" />
          <span class="toggle-slider"></span>
        </label>
      </div>

      <div class="field shortcut-row">
        <label for="shortcut-input">Translation shortcut</label>
        <div class="shortcut-input-wrapper">
          <input type="text" id="shortcut-input" data-testid="shortcut-input" readonly placeholder="Click to record..." />
          <button id="shortcut-clear" data-testid="shortcut-clear" class="shortcut-clear-btn" title="Reset to default">&times;</button>
        </div>
      </div>

      <button data-testid="save-btn" id="save-btn">Save</button>
      <div data-testid="status-msg" id="status-msg"></div>
    </div>
  `;const s=document.getElementById("api-key"),i=document.getElementById("save-btn"),l=document.getElementById("swap-btn"),e=document.getElementById("source-lang"),a=document.getElementById("target-lang"),u=document.getElementById("status-msg"),y=document.getElementById("show-icon-toggle"),b=document.getElementById("youtube-subtitles-toggle"),n=document.getElementById("shortcut-input"),k=document.getElementById("shortcut-clear"),h=document.getElementById("translate-model"),v=document.getElementById("tts-model");let c="system",m=r;n.value=r,chrome.runtime.sendMessage({type:"GET_API_KEY"},t=>{t?.success&&t.data&&(s.value=t.data)}),chrome.runtime.sendMessage({type:"GET_SETTINGS"},t=>{if(t?.success&&t.data){e.value=t.data.sourceLang,a.value=t.data.targetLang,c=t.data.theme??"system",y.checked=t.data.showTriggerIcon!==!1,b.checked=t.data.youtubeSubtitles===!0;const d=t.data.shortcut??r;n.value=d,m=d;const f=t.data.translateModel??w,E=t.data.ttsModel??I;L(c),T(c),chrome.runtime.sendMessage({type:"FETCH_MODELS"},g=>{g?.success&&g.data?(p(h,g.data.translateModels,f),p(v,g.data.ttsModels,E)):(p(h,[],f),p(v,[],E))})}}),document.querySelectorAll(".theme-btn").forEach(t=>{t.addEventListener("click",()=>{c=t.getAttribute("data-theme"),L(c),T(c)})}),n.addEventListener("focus",()=>{n.value="Press keys..."}),n.addEventListener("keydown",t=>{t.preventDefault();const d=S(t);d&&(n.value=d,m=d,n.blur())}),n.addEventListener("blur",()=>{n.value==="Press keys..."&&(n.value=m)}),k.addEventListener("click",()=>{n.value=r,m=r}),i.addEventListener("click",()=>{const t=s.value.trim();if(!t){u.textContent="Please enter a valid API key";return}chrome.runtime.sendMessage({type:"SAVE_API_KEY",apiKey:t},()=>{chrome.runtime.sendMessage({type:"SAVE_SETTINGS",settings:{sourceLang:e.value,targetLang:a.value,theme:c,showTriggerIcon:y.checked,youtubeSubtitles:b.checked,shortcut:n.value,translateModel:h.value,ttsModel:v.value}},()=>{u.textContent="Settings saved"})})}),l.addEventListener("click",()=>{const t=e.value,d=a.value;e.value=d,a.value=t})}M();
